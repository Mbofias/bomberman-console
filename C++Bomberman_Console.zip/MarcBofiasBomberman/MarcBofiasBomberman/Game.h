void InitGame();
void UpdateGame();